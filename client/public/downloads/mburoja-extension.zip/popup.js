"use strict";
(() => {
  // extension/src/lib/config.ts
  var DEFAULT_SERVER = true ? "http://localhost:3000" : "http://localhost:3000";
  async function getSettings() {
    const s = await chrome.storage.local.get(["server", "lang", "autoSubmit", "consentAt"]);
    return {
      server: s.server ?? DEFAULT_SERVER,
      lang: s.lang ?? "sq",
      autoSubmit: s.autoSubmit === true,
      consentAt: s.consentAt ?? null
    };
  }
  async function saveSettings(patch) {
    await chrome.storage.local.set(patch);
  }
  async function getHistory() {
    return (await chrome.storage.local.get("history")).history ?? [];
  }
  var FLAG_COLOR = {
    green: "#16a34a",
    yellow: "#ca8a04",
    orange: "#ea580c",
    red: "#dc2626",
    darkred: "#7f1d1d",
    grey: "#6b7280"
  };
  function originPattern(server) {
    const u = new URL(server);
    return `${u.protocol}//${u.host}/*`;
  }

  // extension/src/lib/i18n.ts
  var sq = {
    appTitle: "Mburoja \xB7 Skaner phishing",
    tabEmail: "Email-i i hapur",
    tabSms: "SMS",
    tabEml: "Skedar EML",
    scanOpen: "Skano email-in e hapur",
    scanOpenHint: "Hap nj\xEB email n\xEB Gmail, Outlook ose nj\xEB webmail tjet\xEBr dhe kliko butonin. Lexohet vet\xEBm ky email, vet\xEBm tani.",
    smsText: "Teksti i SMS-s\xEB",
    smsSender: "D\xEBrguesi (opsional)",
    smsSenderPh: "+355 69\u2026 ose emri i d\xEBrguesit",
    scanSms: "Skano SMS-n\xEB",
    emlFile: "Zgjidh nj\xEB skedar .eml",
    emlHint: 'N\xEB Gmail: \u22EE \u2192 "Shkarko mesazhin". Me EML kontrollohen edhe SPF/DKIM/DMARC.',
    scanEml: "Skano skedarin",
    scanning: "Po analizohet\u2026",
    result: "Rezultati",
    risk: "Rreziku",
    vt: "VirusTotal",
    vtEngines: (n) => `${n} motor\xEB VirusTotal e sh\xEBnuan si malicioz`,
    vtClean: "Asnj\xEB motor nuk e sh\xEBnoi si malicioz",
    vtNone: "Asnj\xEB indikator nuk u kontrollua n\xEB VirusTotal",
    vtNotFound: "i panjohur",
    reasons: "Arsyet kryesore",
    whatToDo: "\xC7far\xEB t\xEB b\xEBsh",
    openSoc: "Hap n\xEB SOC",
    history: "Skanimet e fundit",
    noHistory: "Ende asnj\xEB skanim.",
    settings: "Cil\xEBsimet",
    server: "Adresa e platform\xEBs",
    save: "Ruaj",
    saved: "U ruajt",
    language: "Gjuha",
    resetToken: "Rregjistro s\xEBrish extension-in",
    failed: "Skanimi d\xEBshtoi",
    albania: "Shqip\xEBri",
    sender: "D\xEBrguesi",
    subject: "Subjekti",
    links: "lidhje",
    attachments: "bashk\xEBngjitje",
    extracted: "U lexua",
    menuEmail: "Mburoja: skano tekstin e zgjedhur si email",
    menuSms: "Mburoja: skano tekstin e zgjedhur si SMS",
    privacy: "Skanohet vet\xEBm kur klikon. Platforma maskon t\xEB dh\xEBnat personale para se t'i ruaj\xEB.",
    consentTitle: "D\xEBrgimi automatik te SOC",
    consentRules: [
      "I fikur derisa ta aktivizosh vet\xEB k\xEBtu.",
      "Portokalli, i kuq, i kuq i err\xEBt: d\xEBrgohet nj\xEB raport sinjalesh i maskuar (subjekti dhe 600 karakteret e para, lidhjet e \xE7aktivizuara, domeni i d\xEBrguesit, rezultatet e autentikimit, emrat e bashk\xEBngjitjeve).",
      "E verdh\xEB: vet\xEBm treguesit (lidhjet, domeni, flamuri), pa tekst.",
      "Jeshile dhe gri: nuk d\xEBrgohet asgj\xEB.",
      "\xC7do raport mund ta fshish brenda 10 minutave. Nuk d\xEBrgohen kurr\xEB email-i i plot\xEB, marr\xEBsit ose identiteti yt."
    ],
    consentToggle: "D\xEBrgo automatikisht raporte sinjalesh te SOC",
    consentSince: (d) => `P\xEBlqimi u dha m\xEB ${d}`,
    consentPrompt: "D\xEBshiron q\xEB mesazhet e rrezikshme t'i raportohen automatikisht SOC-ut? Shiko \u201ED\xEBrgimi automatik\u201D te cil\xEBsimet.",
    reportToSoc: "Raporto te SOC",
    reportSent: (p) => `U d\xEBrgua raporti ${p} te SOC.`,
    reportSentIndicators: (p) => `U d\xEBrguan vet\xEBm treguesit (${p}), pa tekst.`,
    sentNotice: (p) => `Raporti ${p} u d\xEBrgua te SOC. Mund ta fshish brenda 10 minutave.`,
    undo: (min) => `Zhb\xEBj / fshi raportin (${min} min)`,
    undone: "Raporti u fshi.",
    autoLabel: "automatikisht",
    exfilTitle: "Ku i d\xEBrgon t\xEB dh\xEBnat ky mesazh",
    exfilKind: { telegram_bot: "Bot Telegram", discord_webhook: "Webhook Discord", webhook: "Webhook", google_apps_script: "Google Apps Script", google_form: "Google Form", form_service: "Sh\xEBrbim formular\xEBsh", php_handler: "Skript PHP", form_action: "Formular", js_endpoint: "K\xEBrkes\xEB nga kodi", mailto: "Email" },
    exfilOther: (n) => `edhe n\xEB ${n} skanime t\xEB tjera`,
    stage: { parsing: "Leximi", iocExtraction: "Indikator\xEBt", heuristics: "Heuristika", virusTotal: "VirusTotal", aiAnalysis: "AI", attribution: "Atribuimi", report: "Raporti" },
    verdict: { malicious: "Malicioz", suspicious: "I dyshimt\xEB", clean: "I past\xEBr", unknown: "I panjohur" },
    flag: { green: "I sigurt", yellow: "Kujdes", orange: "I dyshimt\xEB", red: "Ka gjasa mashtrim", darkred: "Mashtrim i njohur", grey: "Pa vler\xEBsim" },
    errors: {
      server_unreachable: "Platforma nuk u arrit. A \xEBsht\xEB ndezur `npm run dev`?",
      permission_denied: "Nuk u dha leja p\xEBr adres\xEBn e platform\xEBs.",
      no_message: "Nuk u gjet asnj\xEB email i hapur n\xEB k\xEBt\xEB faqe.",
      no_tab: "Nuk ka sked\xEB aktive.",
      cannot_inject: "Kjo faqe nuk lejon skanim (p.sh. faqe e brendshme e browser-it).",
      rate_limited: "U arrit kufiri i skanimeve p\xEBr or\xEB. Provo m\xEB von\xEB.",
      register_rate_limited: "Shum\xEB regjistrime t\xEB extension-it nga ky rrjet brenda nj\xEB ore. Provo s\xEBrish pas pak.",
      open_message: "Hap nj\xEB email (jo list\xEBn e inbox-it) dhe kliko s\xEBrish, ose zgjidh me maus tekstin e email-it.",
      payload_too_large: "Mesazhi \xEBsht\xEB shum\xEB i madh.",
      validation_failed: "T\xEB dh\xEBnat nuk u pranuan nga platforma.",
      unparseable_message: "Skedari nuk u lexua dot si email.",
      file_too_large: "Skedari \xEBsht\xEB mbi 2 MB.",
      msg_unsupported: "Skedar\xEBt .msg nuk mb\xEBshteten ende, p\xEBrdor .eml.",
      empty: "Shkruaj tekstin e SMS-s\xEB.",
      unauthorized: "Regjistrimi i extension-it d\xEBshtoi.",
      timeout: "Analiza po zgjat shum\xEB. Shiko rezultatin n\xEB SOC.",
      not_found: "Platforma nuk e njeh k\xEBt\xEB adres\xEB API.",
      not_ready: "Raporti i skanimit nuk \xEBsht\xEB gati ende.",
      too_late: "Kaluan 10 minuta: raporti nuk mund t\xEB fshihet m\xEB nga extension-i."
    }
  };
  var en = {
    appTitle: "Mburoja \xB7 Phishing scanner",
    tabEmail: "Open email",
    tabSms: "SMS",
    tabEml: "EML file",
    scanOpen: "Scan the open email",
    scanOpenHint: "Open an email in Gmail, Outlook or another webmail and click the button. Only this email is read, only now.",
    smsText: "SMS text",
    smsSender: "Sender (optional)",
    smsSenderPh: "+355 69\u2026 or sender name",
    scanSms: "Scan SMS",
    emlFile: "Choose an .eml file",
    emlHint: 'In Gmail: \u22EE \u2192 "Download message". EML also lets the platform check SPF/DKIM/DMARC.',
    scanEml: "Scan file",
    scanning: "Analysing\u2026",
    result: "Result",
    risk: "Risk",
    vt: "VirusTotal",
    vtEngines: (n) => `${n} VirusTotal engines flagged it as malicious`,
    vtClean: "No engine flagged it as malicious",
    vtNone: "No indicator was checked against VirusTotal",
    vtNotFound: "unknown",
    reasons: "Top reasons",
    whatToDo: "What to do",
    openSoc: "Open in SOC",
    history: "Recent scans",
    noHistory: "No scans yet.",
    settings: "Settings",
    server: "Platform address",
    save: "Save",
    saved: "Saved",
    language: "Language",
    resetToken: "Re-register the extension",
    failed: "Scan failed",
    albania: "Albania",
    sender: "Sender",
    subject: "Subject",
    links: "links",
    attachments: "attachments",
    extracted: "Read",
    menuEmail: "Mburoja: scan selected text as email",
    menuSms: "Mburoja: scan selected text as SMS",
    privacy: "Scans only when you click. The platform masks personal data before storing it.",
    consentTitle: "Auto-submit to the SOC",
    consentRules: [
      "Off until you turn it on here yourself.",
      "Orange, red, dark red: a masked signal report is sent (subject and first 600 characters, defanged links, sender domain, authentication results, attachment names).",
      "Yellow: indicators only (links, domain, flag), no text.",
      "Green and grey: nothing is sent.",
      "You can delete any report within 10 minutes. The full email, recipients and your identity are never sent."
    ],
    consentToggle: "Automatically send signal reports to the SOC",
    consentSince: (d) => `Consent given on ${d}`,
    consentPrompt: "Want dangerous messages reported to the SOC automatically? See \u201CAuto-submit\u201D in settings.",
    reportToSoc: "Report to SOC",
    reportSent: (p) => `Report ${p} was sent to the SOC.`,
    reportSentIndicators: (p) => `Only indicators were sent (${p}), no text.`,
    sentNotice: (p) => `Report ${p} was sent to the SOC. You can delete it within 10 minutes.`,
    undo: (min) => `Undo / delete report (${min} min)`,
    undone: "The report was deleted.",
    autoLabel: "automatically",
    exfilTitle: "Where this message sends your data",
    exfilKind: { telegram_bot: "Telegram bot", discord_webhook: "Discord webhook", webhook: "Webhook", google_apps_script: "Google Apps Script", google_form: "Google Form", form_service: "Form service", php_handler: "PHP script", form_action: "Form", js_endpoint: "Script request", mailto: "Email" },
    exfilOther: (n) => `also in ${n} other scans`,
    stage: { parsing: "Parsing", iocExtraction: "Indicators", heuristics: "Heuristics", virusTotal: "VirusTotal", aiAnalysis: "AI", attribution: "Attribution", report: "Report" },
    verdict: { malicious: "Malicious", suspicious: "Suspicious", clean: "Clean", unknown: "Unknown" },
    flag: { green: "Safe", yellow: "Careful", orange: "Suspicious", red: "Likely scam", darkred: "Known scam", grey: "Not scanned" },
    errors: {
      server_unreachable: "Could not reach the platform. Is `npm run dev` running?",
      permission_denied: "Permission for the platform address was not granted.",
      no_message: "No open email was found on this page.",
      no_tab: "No active tab.",
      cannot_inject: "This page cannot be scanned (for example an internal browser page).",
      rate_limited: "Hourly scan limit reached. Try again later.",
      register_rate_limited: "Too many extension registrations from this network in the last hour. Try again shortly.",
      open_message: "Open an email (not the inbox list) and click again, or select the email text with the mouse.",
      payload_too_large: "The message is too large.",
      validation_failed: "The platform rejected the data.",
      unparseable_message: "The file could not be read as an email.",
      file_too_large: "The file is over 2 MB.",
      msg_unsupported: ".msg files are not supported yet, use .eml.",
      empty: "Type the SMS text.",
      unauthorized: "Extension registration failed.",
      timeout: "Analysis is taking long. See the result in the SOC.",
      not_found: "The platform does not know this API address.",
      not_ready: "The scan report is not ready yet.",
      too_late: "10 minutes have passed: the extension can no longer delete this report."
    }
  };
  var STRINGS = { sq, en };

  // extension/src/popup/popup.ts
  var settings = { server: "http://localhost:3000", lang: "sq", autoSubmit: false, consentAt: null };
  var t = STRINGS.sq;
  var selectedId = null;
  var $ = (id) => document.getElementById(id);
  function el(tag, props = {}, ...children) {
    const node = document.createElement(tag);
    Object.assign(node, props);
    for (const c of children) if (c !== null && c !== void 0) node.append(c);
    return node;
  }
  var SVG = {
    green: "M9 12l2 2 4-4M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z",
    yellow: "M12 9v4m0 4h.01M10.3 3.9L1.8 18a2 2 0 001.7 3h17a2 2 0 001.7-3L13.7 3.9a2 2 0 00-3.4 0z",
    orange: "M12 9v4m0 4h.01M10.3 3.9L1.8 18a2 2 0 001.7 3h17a2 2 0 001.7-3L13.7 3.9a2 2 0 00-3.4 0z",
    red: "M15 9l-6 6m0-6l6 6M7.9 2h8.2L22 7.9v8.2L16.1 22H7.9L2 16.1V7.9z",
    darkred: "M15 9l-6 6m0-6l6 6M7.9 2h8.2L22 7.9v8.2L16.1 22H7.9L2 16.1V7.9z",
    grey: "M9.1 9a3 3 0 015.8 1c0 2-3 3-3 3m.1 4h.01M12 22a10 10 0 100-20 10 10 0 000 20z"
  };
  function flagPill(flag) {
    const pill = el("span", { className: "flag" });
    pill.style.background = FLAG_COLOR[flag];
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("fill", "none");
    svg.setAttribute("stroke", "currentColor");
    svg.setAttribute("stroke-width", "2");
    svg.setAttribute("aria-hidden", "true");
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("d", SVG[flag]);
    svg.append(path);
    pill.append(svg, t.flag[flag]);
    return pill;
  }
  function applyI18n() {
    document.documentElement.lang = settings.lang;
    $("app-title").textContent = t.appTitle;
    $("open-settings").setAttribute("aria-label", t.settings);
    for (const node of Array.from(document.querySelectorAll("[data-i18n]"))) {
      const v = t[node.dataset.i18n];
      if (typeof v === "string") node.textContent = v;
    }
    $("sms-sender").placeholder = t.smsSenderPh;
    $("lang-switch").setAttribute("aria-label", t.language);
    for (const b of Array.from(document.querySelectorAll("#lang-switch [data-lang]"))) {
      const on = b.dataset.lang === settings.lang;
      b.setAttribute("aria-checked", String(on));
      b.tabIndex = on ? 0 : -1;
    }
  }
  async function setLang(lang) {
    if (lang === settings.lang) return;
    await saveSettings({ lang });
    settings = { ...settings, lang };
    t = STRINGS[lang];
    applyI18n();
    renderConsent();
    await render();
  }
  function setupLangSwitch() {
    const buttons = Array.from(document.querySelectorAll("#lang-switch [data-lang]"));
    for (const b of buttons) {
      b.addEventListener("click", () => void setLang(b.dataset.lang));
      b.addEventListener("keydown", (e) => {
        if (!["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(e.key)) return;
        e.preventDefault();
        const next = buttons[(buttons.indexOf(b) + 1) % buttons.length];
        next.focus();
        void setLang(next.dataset.lang);
      });
    }
  }
  function showError(code) {
    const box = $("error");
    if (!code) {
      box.hidden = true;
      return;
    }
    box.textContent = t.errors[code] ?? code;
    box.hidden = false;
  }
  function busy(id, on) {
    const b = $(id);
    b.disabled = on;
    b.textContent = on ? t.scanning : t[b.dataset.i18n];
  }
  function ensurePermission() {
    const origins = [originPattern(settings.server)];
    return chrome.permissions.contains({ origins }).then((has) => has || chrome.permissions.request({ origins }));
  }
  async function send(payload, button, permission) {
    showError(null);
    if (!await permission) return showError("permission_denied");
    busy(button, true);
    try {
      const reply = await chrome.runtime.sendMessage({ type: "scan", payload });
      if (!reply.ok) return showError(reply.error);
      selectedId = reply.scanId;
      await render();
    } finally {
      busy(button, false);
    }
  }
  async function scanOpenEmail(permission) {
    showError(null);
    $("extract-info").textContent = "";
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return showError("no_tab");
    let extracted;
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["extract.js"] });
      const [res] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => globalThis.__mburojaExtract()
      });
      extracted = res?.result;
    } catch {
      return showError("cannot_inject");
    }
    if (!extracted || "error" in extracted) return showError(extracted && "error" in extracted ? extracted.error : "no_message");
    const e = extracted;
    $("extract-info").textContent = `${t.extracted}: ${e.provider} \xB7 ${e.subject ?? "\u2014"} \xB7 ${e.sender ?? "\u2014"} \xB7 ${e.links.length} ${t.links} \xB7 ${e.attachments.length} ${t.attachments}`;
    await send({ kind: "email", email: e }, "scan-open", permission);
  }
  function renderResult(s) {
    const box = $("result");
    box.replaceChildren();
    if (!s) {
      box.hidden = true;
      return;
    }
    box.hidden = false;
    const done = s.status === "completed" || s.status === "partial";
    const lang = settings.lang;
    const head = el("div", { className: "res-head" }, flagPill(s.flag), el("span", { className: "score" }, done && s.risk !== null && s.risk !== void 0 ? `${s.risk}/100` : ""));
    box.append(el("h2", {}, t.result), head, el("p", { className: "res-title", title: s.title }, `${s.channel} \xB7 ${s.title}`));
    if (s.status === "error" || s.status === "failed") {
      box.append(el("p", { className: "error" }, s.error ? t.errors[s.error] ?? s.error : t.failed));
    } else if (!done) {
      const bar = el("div", { className: "progress", role: "progressbar" });
      bar.setAttribute("aria-valuenow", String(s.progress));
      bar.setAttribute("aria-valuemin", "0");
      bar.setAttribute("aria-valuemax", "100");
      bar.setAttribute("aria-label", t.scanning);
      const fill = el("span");
      fill.style.width = `${Math.max(5, s.progress)}%`;
      bar.append(fill);
      const running = Object.entries(s.stages ?? {}).find(([, v]) => v === "running" || v === "pending");
      box.append(bar, el("p", { className: "muted small" }, `${t.scanning} ${running ? t.stage[running[0]] ?? running[0] : ""}`));
    } else {
      const chips = el("div", { className: "chips" });
      if (s.verdict) chips.append(el("span", { className: "chip" }, t.verdict[s.verdict] ?? s.verdict));
      for (const ty of s.types ?? []) chips.append(el("span", { className: "chip" }, ty.replace(/_/g, " ")));
      if (s.family) chips.append(el("span", { className: "chip" }, s.family.replace(/_/g, " ")));
      box.append(chips);
      const vt = el("div", { className: "vt" }, el("h2", {}, t.vt));
      if (!s.vt?.length) vt.append(el("p", { className: "muted small" }, t.vtNone));
      else {
        vt.append(el("p", { className: s.vtMax ? "bad" : "muted small" }, s.vtMax ? t.vtEngines(s.vtMax) : t.vtClean));
        const table = el("table");
        for (const v of s.vt) {
          table.append(
            el(
              "tr",
              {},
              el("td", { className: "mono" }, v.value),
              el("td", { className: `n ${v.malicious ? "bad" : ""}` }, v.found ? `${v.malicious}` : t.vtNotFound),
              el("td", { className: "small" }, v.label ?? "")
            )
          );
        }
        vt.append(table);
      }
      box.append(vt);
      if (s.exfil?.length) {
        const ex = el("div", { className: "exfil", role: "note" }, el("h2", {}, t.exfilTitle));
        for (const e of s.exfil) {
          ex.append(el("p", { className: "small" }, el("strong", {}, t.exfilKind[e.kind] ?? e.kind), " \xB7 ", el("span", { className: "mono" }, e.value), e.otherScans ? ` \xB7 ${t.exfilOther(e.otherScans)}` : ""));
        }
        box.append(ex);
      }
      if (s.reasons?.length) box.append(el("h2", {}, t.reasons), el("ul", {}, ...s.reasons.map((r) => el("li", {}, r[lang]))));
      if (s.actions?.length) box.append(el("h2", {}, t.whatToDo), el("ul", {}, ...s.actions.map((a) => el("li", {}, a[lang]))));
    }
    const row = el("div", { className: "row" });
    if (done) box.append(...reportBlock(s), row);
    else box.append(row);
    if (done && s.flag !== "grey" && s.signal && (!s.submitted || s.submitted.deleted)) {
      const report = el("button", { type: "button", className: "btn primary" }, t.reportToSoc);
      report.addEventListener("click", () => {
        report.disabled = true;
        void chrome.runtime.sendMessage({ type: "report", scanId: s.scanId }).then((r) => {
          if (!r.ok) showError(r.error);
          void render();
        });
      });
      row.append(report);
    }
    const open = el("button", { type: "button", className: "btn" }, t.openSoc);
    open.addEventListener("click", () => void chrome.tabs.create({ url: `${settings.server.replace(/\/$/, "")}/${lang}/soc/intel/${s.scanId}` }));
    row.append(open);
  }
  function reportBlock(s) {
    const out = [];
    if (s.submitError) out.push(el("p", { className: "error" }, t.errors[s.submitError] ?? s.submitError));
    const sub = s.submitted;
    if (!sub) return out;
    if (sub.deleted) return [...out, el("p", { className: "sent small" }, t.undone)];
    const text = (sub.indicatorsOnly ? t.reportSentIndicators(sub.protocol) : t.reportSent(sub.protocol)) + (sub.auto ? ` (${t.autoLabel})` : "");
    const block = el("div", { className: "sent", role: "status" }, el("p", { className: "small" }, text));
    const left = Math.ceil((Date.parse(sub.deleteUntil) - Date.now()) / 6e4);
    if (left > 0) {
      const undo = el("button", { type: "button", className: "btn" }, t.undo(left));
      undo.addEventListener("click", () => {
        undo.disabled = true;
        void chrome.runtime.sendMessage({ type: "undo-report", scanId: s.scanId }).then((r) => {
          if (!r.ok) showError(r.error);
          void render();
        });
      });
      block.append(undo);
    }
    out.push(block);
    return out;
  }
  function renderConsent() {
    const rules = $("consent-rules");
    rules.replaceChildren(...t.consentRules.map((r) => el("li", {}, r)));
    $("auto-submit").checked = settings.autoSubmit;
    $("consent-since").textContent = settings.autoSubmit && settings.consentAt ? t.consentSince(new Date(settings.consentAt).toLocaleString(settings.lang === "sq" ? "sq-AL" : "en-GB")) : "";
    const prompt = $("consent-prompt");
    prompt.textContent = t.consentPrompt;
    prompt.hidden = settings.consentAt !== null;
  }
  async function render() {
    const history = await getHistory();
    const current = (await chrome.storage.local.get("current")).current;
    const id = selectedId ?? current ?? history[0]?.scanId;
    renderResult(history.find((h) => h.scanId === id));
    const list = $("history-list");
    list.replaceChildren();
    if (!history.length) list.append(el("li", { className: "muted small" }, t.noHistory));
    for (const h of history.slice(0, 6)) {
      const dot = el("span", { className: "dot" });
      dot.style.background = FLAG_COLOR[h.flag];
      const b = el("button", { type: "button" }, dot, el("span", { className: "h-title" }, `${h.channel} \xB7 ${h.title}`), el("span", { className: "small muted" }, h.risk !== null && h.risk !== void 0 ? `${h.risk}` : "\u2026"));
      b.setAttribute("aria-label", `${t.flag[h.flag]} \xB7 ${h.title}`);
      b.addEventListener("click", () => {
        selectedId = h.scanId;
        void render();
      });
      list.append(el("li", {}, b));
    }
  }
  function setupTabs() {
    const tabs = Array.from(document.querySelectorAll("[role='tab']"));
    const select = (tab) => {
      for (const x of tabs) {
        const on = x === tab;
        x.setAttribute("aria-selected", String(on));
        x.tabIndex = on ? 0 : -1;
        $(x.getAttribute("aria-controls")).hidden = !on;
      }
      tab.focus();
    };
    tabs.forEach((tab, i) => {
      tab.addEventListener("click", () => select(tab));
      tab.addEventListener("keydown", (e) => {
        if (e.key === "ArrowRight") select(tabs[(i + 1) % tabs.length]);
        if (e.key === "ArrowLeft") select(tabs[(i - 1 + tabs.length) % tabs.length]);
      });
    });
  }
  async function init() {
    settings = await getSettings();
    t = STRINGS[settings.lang];
    applyI18n();
    setupTabs();
    setupLangSwitch();
    $("server").value = settings.server;
    $("open-settings").addEventListener("click", () => {
      const panel = $("settings");
      panel.hidden = !panel.hidden;
      $("open-settings").setAttribute("aria-expanded", String(!panel.hidden));
    });
    $("save-settings").addEventListener("click", () => {
      const server = $("server").value.trim().replace(/\/$/, "");
      let valid = false;
      try {
        valid = /^https?:$/.test(new URL(server).protocol);
      } catch {
        valid = false;
      }
      if (!valid) return showError("not_found");
      const permission = chrome.permissions.request({ origins: [originPattern(server)] });
      void permission.then(async (granted) => {
        if (!granted) return showError("permission_denied");
        await saveSettings({ server });
        settings = await getSettings();
        t = STRINGS[settings.lang];
        applyI18n();
        renderConsent();
        $("settings-status").textContent = t.saved;
        await render();
      });
    });
    $("reset-token").addEventListener("click", () => void chrome.runtime.sendMessage({ type: "reset-token" }).then(() => $("settings-status").textContent = t.saved));
    $("auto-submit").addEventListener("change", (e) => {
      const on = e.target.checked;
      const patch = { autoSubmit: on, ...on ? { consentAt: (/* @__PURE__ */ new Date()).toISOString() } : {} };
      void saveSettings(patch).then(async () => {
        settings = await getSettings();
        renderConsent();
      });
    });
    renderConsent();
    setInterval(() => void render(), 3e4);
    $("scan-open").addEventListener("click", () => {
      const permission = ensurePermission();
      busy("scan-open", true);
      void scanOpenEmail(permission).finally(() => busy("scan-open", false));
    });
    $("scan-sms").addEventListener("click", () => {
      const text = $("sms-text").value.trim();
      if (!text) return showError("empty");
      const sender = $("sms-sender").value.trim() || void 0;
      void send({ kind: "sms", text, sender }, "scan-sms", ensurePermission());
    });
    $("scan-eml").addEventListener("click", () => {
      const file = $("eml-file").files?.[0];
      if (!file) return showError("unparseable_message");
      if (/\.msg$/i.test(file.name)) return showError("msg_unsupported");
      if (file.size > 2e6) return showError("file_too_large");
      const permission = ensurePermission();
      void file.text().then((raw) => send({ kind: "eml", raw, fileName: file.name }, "scan-eml", permission));
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && (changes.history || changes.current)) void render();
    });
    await render();
  }
  void init();
})();
