"use strict";
(() => {
  // extension/src/lib/api.ts
  var ApiError = class extends Error {
    constructor(status, code, message) {
      super(message);
      this.status = status;
      this.code = code;
    }
    status;
    code;
  };
  async function call(server, path, init = {}) {
    const headers = { accept: "application/json" };
    if (init.body) headers["content-type"] = "application/json";
    if (init.token) headers.authorization = `Bearer ${init.token}`;
    let res;
    try {
      res = await fetch(`${server.replace(/\/$/, "")}${path}`, { ...init, headers, credentials: "omit", cache: "no-store" });
    } catch {
      throw new ApiError(0, "network", "server_unreachable");
    }
    const body = await res.json().catch(() => null);
    if (!res.ok) throw new ApiError(res.status, body?.error?.code ?? "http_error", body?.error?.message ?? `HTTP ${res.status}`);
    return body;
  }
  function randomHex(bytes) {
    return Array.from(crypto.getRandomValues(new Uint8Array(bytes)), (b) => b.toString(16).padStart(2, "0")).join("");
  }
  async function getToken(server, force = false) {
    const key = `token:${server}`;
    if (!force) {
      const stored = (await chrome.storage.local.get(key))[key];
      if (stored) return stored;
    }
    let installHash = (await chrome.storage.local.get("installHash")).installHash;
    if (!installHash) {
      installHash = randomHex(24);
      await chrome.storage.local.set({ installHash });
    }
    const { installToken } = await call(server, "/api/v1/extension/register", {
      method: "POST",
      body: JSON.stringify({ installHash, version: chrome.runtime.getManifest().version })
    });
    await chrome.storage.local.set({ [key]: installToken });
    return installToken;
  }
  async function authed(server, path, init = {}) {
    try {
      return await call(server, path, { ...init, token: await getToken(server) });
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) return call(server, path, { ...init, token: await getToken(server, true) });
      throw e;
    }
  }
  function toRequest(p, locale) {
    const options = { locale, useVirusTotal: true, aiMode: "hybrid", allowCloudAnalysis: true, threatAttribution: true };
    switch (p.kind) {
      case "email": {
        const e = p.email;
        return {
          channel: "EMAIL",
          source: e.provider,
          email: {
            subject: e.subject?.slice(0, 998),
            sender: e.sender?.slice(0, 320),
            replyTo: e.replyTo?.slice(0, 320),
            body: e.body,
            html: e.html,
            urls: [...new Set(e.links.map((l) => l.href))].filter((u) => u.length <= 2048).slice(0, 200),
            attachments: e.attachments.map((a) => ({ name: a.name.slice(0, 255), mime: a.mime, size: a.size }))
          },
          options
        };
      }
      case "eml":
        return { channel: "EMAIL", source: "eml", email: { raw: p.raw }, options };
      case "sms":
        return { channel: "SMS", source: "manual_input", message: { text: p.text.slice(0, 5e3), ...p.sender ? { sender: p.sender.slice(0, 64) } : {} }, options };
      case "selection":
        return p.as === "sms" ? { channel: "SMS", source: "manual_input", message: { text: p.text.slice(0, 5e3) }, options } : { channel: "EMAIL", source: "webmail", email: { body: p.text.slice(0, 9e4) }, options };
    }
  }
  function submitSignal(server, signals) {
    return authed(server, "/api/v1/extension/reports", { method: "POST", body: JSON.stringify({ signals, consent: true }) });
  }
  async function deleteSignal(server, reportId) {
    await authed(server, `/api/v1/extension/reports/${reportId}`, { method: "DELETE" });
  }

  // extension/src/lib/config.ts
  var DEFAULT_SERVER = true ? "http://localhost:3000" : "http://localhost:3000";
  var HISTORY_MAX = 20;
  async function getSettings() {
    const s = await chrome.storage.local.get(["server", "lang", "autoSubmit", "consentAt"]);
    return {
      server: s.server ?? DEFAULT_SERVER,
      lang: s.lang ?? "sq",
      autoSubmit: s.autoSubmit === true,
      consentAt: s.consentAt ?? null
    };
  }
  async function getHistory() {
    return (await chrome.storage.local.get("history")).history ?? [];
  }
  async function upsertHistory(item) {
    const list = (await getHistory()).filter((h) => h.scanId !== item.scanId);
    await chrome.storage.local.set({ history: [item, ...list].slice(0, HISTORY_MAX), current: item.scanId });
  }
  function flagFor(risk, done) {
    if (!done || risk === null || risk === void 0) return "grey";
    if (risk >= 80) return "darkred";
    if (risk >= 60) return "red";
    if (risk >= 40) return "orange";
    if (risk >= 20) return "yellow";
    return "green";
  }
  var FLAG_COLOR = {
    green: "#16a34a",
    yellow: "#ca8a04",
    orange: "#ea580c",
    red: "#dc2626",
    darkred: "#7f1d1d",
    grey: "#6b7280"
  };

  // extension/src/lib/i18n.ts
  var sq = {
    appTitle: "Mburoja \xB7 Skaner phishing",
    tabEmail: "Email-i i hapur",
    tabSms: "SMS",
    tabEml: "Skedar EML",
    scanOpen: "Skano email-in e hapur",
    scanOpenHint: "Hap nj\xEB email n\xEB Gmail, Outlook ose nj\xEB webmail tjet\xEBr dhe kliko butonin. Lexohet vet\xEBm ky email, vet\xEBm tani.",
    smsText: "Teksti i SMS-s\xEB",
    smsSender: "D\xEBrguesi (opsional)",
    smsSenderPh: "+355 69\u2026 ose emri i d\xEBrguesit",
    scanSms: "Skano SMS-n\xEB",
    emlFile: "Zgjidh nj\xEB skedar .eml",
    emlHint: 'N\xEB Gmail: \u22EE \u2192 "Shkarko mesazhin". Me EML kontrollohen edhe SPF/DKIM/DMARC.',
    scanEml: "Skano skedarin",
    scanning: "Po analizohet\u2026",
    result: "Rezultati",
    risk: "Rreziku",
    vt: "VirusTotal",
    vtEngines: (n) => `${n} motor\xEB VirusTotal e sh\xEBnuan si malicioz`,
    vtClean: "Asnj\xEB motor nuk e sh\xEBnoi si malicioz",
    vtNone: "Asnj\xEB indikator nuk u kontrollua n\xEB VirusTotal",
    vtNotFound: "i panjohur",
    reasons: "Arsyet kryesore",
    whatToDo: "\xC7far\xEB t\xEB b\xEBsh",
    openSoc: "Hap n\xEB SOC",
    history: "Skanimet e fundit",
    noHistory: "Ende asnj\xEB skanim.",
    settings: "Cil\xEBsimet",
    server: "Adresa e platform\xEBs",
    save: "Ruaj",
    saved: "U ruajt",
    language: "Gjuha",
    resetToken: "Rregjistro s\xEBrish extension-in",
    failed: "Skanimi d\xEBshtoi",
    albania: "Shqip\xEBri",
    sender: "D\xEBrguesi",
    subject: "Subjekti",
    links: "lidhje",
    attachments: "bashk\xEBngjitje",
    extracted: "U lexua",
    menuEmail: "Mburoja: skano tekstin e zgjedhur si email",
    menuSms: "Mburoja: skano tekstin e zgjedhur si SMS",
    privacy: "Skanohet vet\xEBm kur klikon. Platforma maskon t\xEB dh\xEBnat personale para se t'i ruaj\xEB.",
    consentTitle: "D\xEBrgimi automatik te SOC",
    consentRules: [
      "I fikur derisa ta aktivizosh vet\xEB k\xEBtu.",
      "Portokalli, i kuq, i kuq i err\xEBt: d\xEBrgohet nj\xEB raport sinjalesh i maskuar (subjekti dhe 600 karakteret e para, lidhjet e \xE7aktivizuara, domeni i d\xEBrguesit, rezultatet e autentikimit, emrat e bashk\xEBngjitjeve).",
      "E verdh\xEB: vet\xEBm treguesit (lidhjet, domeni, flamuri), pa tekst.",
      "Jeshile dhe gri: nuk d\xEBrgohet asgj\xEB.",
      "\xC7do raport mund ta fshish brenda 10 minutave. Nuk d\xEBrgohen kurr\xEB email-i i plot\xEB, marr\xEBsit ose identiteti yt."
    ],
    consentToggle: "D\xEBrgo automatikisht raporte sinjalesh te SOC",
    consentSince: (d) => `P\xEBlqimi u dha m\xEB ${d}`,
    consentPrompt: "D\xEBshiron q\xEB mesazhet e rrezikshme t'i raportohen automatikisht SOC-ut? Shiko \u201ED\xEBrgimi automatik\u201D te cil\xEBsimet.",
    reportToSoc: "Raporto te SOC",
    reportSent: (p) => `U d\xEBrgua raporti ${p} te SOC.`,
    reportSentIndicators: (p) => `U d\xEBrguan vet\xEBm treguesit (${p}), pa tekst.`,
    sentNotice: (p) => `Raporti ${p} u d\xEBrgua te SOC. Mund ta fshish brenda 10 minutave.`,
    undo: (min) => `Zhb\xEBj / fshi raportin (${min} min)`,
    undone: "Raporti u fshi.",
    autoLabel: "automatikisht",
    exfilTitle: "Ku i d\xEBrgon t\xEB dh\xEBnat ky mesazh",
    exfilKind: { telegram_bot: "Bot Telegram", discord_webhook: "Webhook Discord", webhook: "Webhook", google_apps_script: "Google Apps Script", google_form: "Google Form", form_service: "Sh\xEBrbim formular\xEBsh", php_handler: "Skript PHP", form_action: "Formular", js_endpoint: "K\xEBrkes\xEB nga kodi", mailto: "Email" },
    exfilOther: (n) => `edhe n\xEB ${n} skanime t\xEB tjera`,
    stage: { parsing: "Leximi", iocExtraction: "Indikator\xEBt", heuristics: "Heuristika", virusTotal: "VirusTotal", aiAnalysis: "AI", attribution: "Atribuimi", report: "Raporti" },
    verdict: { malicious: "Malicioz", suspicious: "I dyshimt\xEB", clean: "I past\xEBr", unknown: "I panjohur" },
    flag: { green: "I sigurt", yellow: "Kujdes", orange: "I dyshimt\xEB", red: "Ka gjasa mashtrim", darkred: "Mashtrim i njohur", grey: "Pa vler\xEBsim" },
    errors: {
      server_unreachable: "Platforma nuk u arrit. A \xEBsht\xEB ndezur `npm run dev`?",
      permission_denied: "Nuk u dha leja p\xEBr adres\xEBn e platform\xEBs.",
      no_message: "Nuk u gjet asnj\xEB email i hapur n\xEB k\xEBt\xEB faqe.",
      no_tab: "Nuk ka sked\xEB aktive.",
      cannot_inject: "Kjo faqe nuk lejon skanim (p.sh. faqe e brendshme e browser-it).",
      rate_limited: "U arrit kufiri i skanimeve p\xEBr or\xEB. Provo m\xEB von\xEB.",
      register_rate_limited: "Shum\xEB regjistrime t\xEB extension-it nga ky rrjet brenda nj\xEB ore. Provo s\xEBrish pas pak.",
      open_message: "Hap nj\xEB email (jo list\xEBn e inbox-it) dhe kliko s\xEBrish, ose zgjidh me maus tekstin e email-it.",
      payload_too_large: "Mesazhi \xEBsht\xEB shum\xEB i madh.",
      validation_failed: "T\xEB dh\xEBnat nuk u pranuan nga platforma.",
      unparseable_message: "Skedari nuk u lexua dot si email.",
      file_too_large: "Skedari \xEBsht\xEB mbi 2 MB.",
      msg_unsupported: "Skedar\xEBt .msg nuk mb\xEBshteten ende, p\xEBrdor .eml.",
      empty: "Shkruaj tekstin e SMS-s\xEB.",
      unauthorized: "Regjistrimi i extension-it d\xEBshtoi.",
      timeout: "Analiza po zgjat shum\xEB. Shiko rezultatin n\xEB SOC.",
      not_found: "Platforma nuk e njeh k\xEBt\xEB adres\xEB API.",
      not_ready: "Raporti i skanimit nuk \xEBsht\xEB gati ende.",
      too_late: "Kaluan 10 minuta: raporti nuk mund t\xEB fshihet m\xEB nga extension-i."
    }
  };
  var en = {
    appTitle: "Mburoja \xB7 Phishing scanner",
    tabEmail: "Open email",
    tabSms: "SMS",
    tabEml: "EML file",
    scanOpen: "Scan the open email",
    scanOpenHint: "Open an email in Gmail, Outlook or another webmail and click the button. Only this email is read, only now.",
    smsText: "SMS text",
    smsSender: "Sender (optional)",
    smsSenderPh: "+355 69\u2026 or sender name",
    scanSms: "Scan SMS",
    emlFile: "Choose an .eml file",
    emlHint: 'In Gmail: \u22EE \u2192 "Download message". EML also lets the platform check SPF/DKIM/DMARC.',
    scanEml: "Scan file",
    scanning: "Analysing\u2026",
    result: "Result",
    risk: "Risk",
    vt: "VirusTotal",
    vtEngines: (n) => `${n} VirusTotal engines flagged it as malicious`,
    vtClean: "No engine flagged it as malicious",
    vtNone: "No indicator was checked against VirusTotal",
    vtNotFound: "unknown",
    reasons: "Top reasons",
    whatToDo: "What to do",
    openSoc: "Open in SOC",
    history: "Recent scans",
    noHistory: "No scans yet.",
    settings: "Settings",
    server: "Platform address",
    save: "Save",
    saved: "Saved",
    language: "Language",
    resetToken: "Re-register the extension",
    failed: "Scan failed",
    albania: "Albania",
    sender: "Sender",
    subject: "Subject",
    links: "links",
    attachments: "attachments",
    extracted: "Read",
    menuEmail: "Mburoja: scan selected text as email",
    menuSms: "Mburoja: scan selected text as SMS",
    privacy: "Scans only when you click. The platform masks personal data before storing it.",
    consentTitle: "Auto-submit to the SOC",
    consentRules: [
      "Off until you turn it on here yourself.",
      "Orange, red, dark red: a masked signal report is sent (subject and first 600 characters, defanged links, sender domain, authentication results, attachment names).",
      "Yellow: indicators only (links, domain, flag), no text.",
      "Green and grey: nothing is sent.",
      "You can delete any report within 10 minutes. The full email, recipients and your identity are never sent."
    ],
    consentToggle: "Automatically send signal reports to the SOC",
    consentSince: (d) => `Consent given on ${d}`,
    consentPrompt: "Want dangerous messages reported to the SOC automatically? See \u201CAuto-submit\u201D in settings.",
    reportToSoc: "Report to SOC",
    reportSent: (p) => `Report ${p} was sent to the SOC.`,
    reportSentIndicators: (p) => `Only indicators were sent (${p}), no text.`,
    sentNotice: (p) => `Report ${p} was sent to the SOC. You can delete it within 10 minutes.`,
    undo: (min) => `Undo / delete report (${min} min)`,
    undone: "The report was deleted.",
    autoLabel: "automatically",
    exfilTitle: "Where this message sends your data",
    exfilKind: { telegram_bot: "Telegram bot", discord_webhook: "Discord webhook", webhook: "Webhook", google_apps_script: "Google Apps Script", google_form: "Google Form", form_service: "Form service", php_handler: "PHP script", form_action: "Form", js_endpoint: "Script request", mailto: "Email" },
    exfilOther: (n) => `also in ${n} other scans`,
    stage: { parsing: "Parsing", iocExtraction: "Indicators", heuristics: "Heuristics", virusTotal: "VirusTotal", aiAnalysis: "AI", attribution: "Attribution", report: "Report" },
    verdict: { malicious: "Malicious", suspicious: "Suspicious", clean: "Clean", unknown: "Unknown" },
    flag: { green: "Safe", yellow: "Careful", orange: "Suspicious", red: "Likely scam", darkred: "Known scam", grey: "Not scanned" },
    errors: {
      server_unreachable: "Could not reach the platform. Is `npm run dev` running?",
      permission_denied: "Permission for the platform address was not granted.",
      no_message: "No open email was found on this page.",
      no_tab: "No active tab.",
      cannot_inject: "This page cannot be scanned (for example an internal browser page).",
      rate_limited: "Hourly scan limit reached. Try again later.",
      register_rate_limited: "Too many extension registrations from this network in the last hour. Try again shortly.",
      open_message: "Open an email (not the inbox list) and click again, or select the email text with the mouse.",
      payload_too_large: "The message is too large.",
      validation_failed: "The platform rejected the data.",
      unparseable_message: "The file could not be read as an email.",
      file_too_large: "The file is over 2 MB.",
      msg_unsupported: ".msg files are not supported yet, use .eml.",
      empty: "Type the SMS text.",
      unauthorized: "Extension registration failed.",
      timeout: "Analysis is taking long. See the result in the SOC.",
      not_found: "The platform does not know this API address.",
      not_ready: "The scan report is not ready yet.",
      too_late: "10 minutes have passed: the extension can no longer delete this report."
    }
  };
  var STRINGS = { sq, en };

  // src/server/detection/masks.ts
  var MASK_TOKENS = {
    email: "[EMAIL]",
    iban: "[IBAN]",
    card: "[CARD]",
    phone: "[PHONE]",
    id: "[ID]",
    name: "[NAME]"
  };
  var PII_PATTERNS = {
    email: /\b[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,24}\b/gi,
    iban: /\b[A-Z]{2}\d{2}(?:[ ]?[A-Z0-9]{4}){2,7}(?:[ ]?[A-Z0-9]{1,4})?\b/g,
    card: /\b\d{4}(?:[ -]?\d{4}){2}(?:[ -]?\d{1,7})\b/g,
    phone: /(?:\+|\b00)355[\s.-]?\d(?:[\s.-]?\d){7,8}\b|\b0[2-9]\d?(?:[\s.-]?\d){6,8}\b/g,
    // Albanian personal number (NID): letter, 8 digits, letter. Also plain 10-digit IDs.
    id: /\b[A-T]\d{8}[A-W]\b|\b\d{10}\b/gi
  };
  var SALUTATIONS = "(?:I nderuar|E nderuar|T\xEB nderuar|Te nderuar|P\xEBrsh\xEBndetje|Pershendetje|Tungjatjeta|Zoti|Zonja|Z\\.|Znj\\.|I dashur|E dashur|Dear|Hello|Hi|Mr\\.?|Mrs\\.?|Ms\\.?)";
  var NAME_RE = new RegExp(
    `(${SALUTATIONS}[ ,]+)(\\p{Lu}[\\p{Ll}'-]+(?:[ ]+\\p{Lu}[\\p{Ll}'-]+){0,2})`,
    "gu"
  );
  function mask(input) {
    const counts = { email: 0, iban: 0, card: 0, phone: 0, id: 0, name: 0 };
    let text = input;
    for (const kind of ["email", "iban", "card", "phone", "id"]) {
      text = text.replace(PII_PATTERNS[kind], () => {
        counts[kind] += 1;
        return MASK_TOKENS[kind];
      });
    }
    text = text.replace(NAME_RE, (_m, salutation, name) => {
      if (name.startsWith("[")) return `${salutation}${name}`;
      counts.name += 1;
      return `${salutation}${MASK_TOKENS.name}`;
    });
    return { text, counts };
  }
  function maskText(input) {
    return mask(input).text;
  }

  // extension/src/lib/signal.ts
  function autoMode(flag) {
    if (flag === "orange" || flag === "red" || flag === "darkred") return "full";
    if (flag === "yellow") return "indicators";
    return "none";
  }
  var toAuth = (v) => v === "pass" ? "pass" : v === "fail" || v === "softfail" ? "fail" : "none";
  function indicatorsOnly(s) {
    const { subject: _subject, bodyExcerpt: _body, ...rest } = s;
    void _subject;
    void _body;
    return { ...rest, attachments: [], indicatorsOnly: true };
  }
  function buildSignal(report, flag, version, mode) {
    const email = report.evidence.email;
    const sms = report.evidence.sms;
    const indicatorsOnly2 = mode === "indicators";
    const senderDomain = email?.from?.match(/@([a-z0-9.-]+\.[a-z]{2,})/i)?.[1]?.toLowerCase();
    const reasonCodes = [
      ...report.evidence.engineReasons.filter((r) => r.weight > 0).map((r) => r.code),
      ...report.evidence.findings.map((f) => f.code)
    ];
    const signal = {
      urls: report.iocs.filter((i) => i.type === "url").map((i) => i.value).filter((u) => u.length <= 2048).slice(0, 50),
      ...senderDomain && senderDomain.length <= 253 ? { senderDomain } : {},
      ...email && email.authentication.source !== "absent" ? { auth: { spf: toAuth(email.authentication.spf), dkim: toAuth(email.authentication.dkim), dmarc: toAuth(email.authentication.dmarc) } } : {},
      attachments: [],
      score: Math.max(0, Math.min(100, Math.round(report.riskScore))),
      flag,
      reasonCodes: [...new Set(reasonCodes)].filter((c) => c.length <= 64).slice(0, 20),
      version,
      channel: sms ? "sms" : "email"
    };
    if (indicatorsOnly2) return { ...signal, indicatorsOnly: true };
    const subject = email?.subject ? maskText(email.subject).slice(0, 300) : void 0;
    const excerpt = (email?.excerpt ?? sms?.excerpt ?? "").trim();
    return {
      ...signal,
      ...subject ? { subject } : {},
      ...excerpt ? { bodyExcerpt: maskText(excerpt).slice(0, 600) } : {},
      attachments: (email?.attachments ?? []).slice(0, 20).map((a) => ({ name: a.name.slice(0, 255), mime: a.mime.slice(0, 255) }))
    };
  }

  // extension/src/background.ts
  var errorCode = (e) => e instanceof ApiError ? e.code === "network" ? "server_unreachable" : e.code : "unknown";
  async function submitReport(scanId, mode, auto) {
    const s = (await getHistory()).find((h) => h.scanId === scanId);
    if (!s?.signal) return { ok: false, error: "not_ready" };
    if (s.submitted && !s.submitted.deleted) return { ok: true, scanId };
    const { server } = await getSettings();
    const signal = mode === "indicators" ? indicatorsOnly(s.signal) : s.signal;
    try {
      const r = await submitSignal(server, signal);
      await upsertHistory({ ...s, submitError: void 0, submitted: { ...r, indicatorsOnly: mode === "indicators", auto } });
      return { ok: true, scanId };
    } catch (e) {
      await upsertHistory({ ...s, submitError: errorCode(e) });
      return { ok: false, error: errorCode(e) };
    }
  }
  async function undoReport(scanId) {
    const s = (await getHistory()).find((h) => h.scanId === scanId);
    if (!s?.submitted || s.submitted.deleted) return { ok: false, error: "not_found" };
    if (Date.parse(s.submitted.deleteUntil) < Date.now()) return { ok: false, error: "too_late" };
    try {
      await deleteSignal((await getSettings()).server, s.submitted.reportId);
      await upsertHistory({ ...s, submitted: { ...s.submitted, deleted: true } });
      return { ok: true, scanId };
    } catch (e) {
      return { ok: false, error: errorCode(e) };
    }
  }
  var POLL_MS = 1500;
  var POLL_LIMIT_MS = 12e4;
  function titleOf(p) {
    switch (p.kind) {
      case "email":
        return p.email.subject || p.email.sender || "Email";
      case "eml":
        return p.fileName;
      case "sms":
        return p.text.slice(0, 80);
      case "selection":
        return p.text.slice(0, 80);
    }
  }
  async function setBadge(tabId, s) {
    const done = s.status === "completed" || s.status === "partial";
    const text = !done ? "\u2026" : s.flag === "green" ? "\u2713" : s.flag === "yellow" ? "!" : "!!";
    const opts = tabId === void 0 ? {} : { tabId };
    await chrome.action.setBadgeBackgroundColor({ color: FLAG_COLOR[s.flag], ...opts });
    await chrome.action.setBadgeText({ text, ...opts });
  }
  async function notify(s) {
    const { lang } = await getSettings();
    const t = STRINGS[lang];
    const done = s.status === "completed" || s.status === "partial";
    try {
      await chrome.notifications.create(`scan-${s.scanId}`, {
        type: "basic",
        iconUrl: chrome.runtime.getURL("icons/icon-128.png"),
        title: done ? `${t.flag[s.flag]} \xB7 ${s.risk ?? "\u2013"}/100` : t.failed,
        message: done ? `${s.title}
${s.vtMax ? t.vtEngines(s.vtMax) : t.verdict[s.verdict] ?? ""}${s.submitted ? `
${t.sentNotice(s.submitted.protocol)}` : ""}` : s.error ?? "",
        priority: s.flag === "red" || s.flag === "darkred" ? 2 : 0
      });
    } catch {
    }
  }
  function summarise(base, st, report) {
    const done = st.status === "completed" || st.status === "partial";
    const risk = report?.riskScore ?? st.riskScore;
    const vt = (report?.reputation.results ?? []).map((r) => ({
      type: r.type,
      value: r.value,
      malicious: r.malicious,
      suspicious: r.suspicious,
      found: r.found,
      label: r.threatLabel ?? r.categories[0] ?? null
    }));
    return {
      ...base,
      channel: st.channel,
      status: st.status,
      progress: st.progress,
      stages: st.stages,
      verdict: report?.verdict ?? st.verdict,
      risk,
      severity: report?.severity ?? st.severity,
      flag: flagFor(risk, done),
      vtMax: vt.length ? Math.max(...vt.map((v) => v.malicious)) : null,
      vt: vt.slice(0, 6),
      reasons: (report?.evidence.engineReasons ?? []).filter((r) => r.weight > 0).sort((a, b) => b.weight - a.weight).slice(0, 3).map((r) => ({ sq: r.text_sq, en: r.text_en, weight: r.weight })),
      types: report?.classification.phishingType.map((c) => c.value) ?? (st.phishingType ? [st.phishingType] : []),
      family: report?.classification.phishingFamily[0]?.value ?? st.phishingFamily,
      exfil: report?.exfil?.endpoints.slice(0, 3).map((e) => ({ kind: e.kind, value: e.value, otherScans: e.otherScans })),
      actions: report?.recommendedActions.slice(0, 4)
    };
  }
  async function runScan(payload, tabId) {
    const { server, lang } = await getSettings();
    let created;
    try {
      created = await authed(server, "/api/phishing-intelligence/scan", { method: "POST", body: JSON.stringify(toRequest(payload, lang)) });
    } catch (e) {
      return { ok: false, error: errorCode(e) };
    }
    let summary = {
      scanId: created.scanId,
      title: titleOf(payload),
      channel: payload.kind === "sms" || payload.kind === "selection" && payload.as === "sms" ? "SMS" : "EMAIL",
      status: "queued",
      progress: 0,
      flag: "grey",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await upsertHistory(summary);
    await setBadge(tabId, summary);
    void (async () => {
      const started = Date.now();
      while (Date.now() - started < POLL_LIMIT_MS) {
        await new Promise((r) => setTimeout(r, POLL_MS));
        let st;
        try {
          st = await authed(server, `/api/phishing-intelligence/scans/${created.scanId}`);
        } catch {
          continue;
        }
        const done = st.status === "completed" || st.status === "partial";
        let report = null;
        if (done) {
          try {
            report = await authed(server, `/api/phishing-intelligence/reports/${created.scanId}`);
          } catch {
            report = null;
          }
        }
        summary = summarise(summary, st, report);
        if (done && report && summary.flag !== "grey") {
          summary.signal = buildSignal(report, summary.flag, chrome.runtime.getManifest().version, "full");
        }
        await upsertHistory(summary);
        if (done || st.status === "failed") {
          const { autoSubmit } = await getSettings();
          const mode = autoSubmit && summary.signal ? autoMode(summary.flag) : "none";
          if (mode !== "none") await submitReport(summary.scanId, mode, true);
          const latest = (await getHistory()).find((h) => h.scanId === summary.scanId) ?? summary;
          await setBadge(tabId, latest);
          await notify(latest);
          return;
        }
      }
      summary = { ...summary, status: "error", error: "timeout" };
      await upsertHistory(summary);
    })();
    return { ok: true, scanId: created.scanId };
  }
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "scan") {
      void runScan(msg.payload, sender.tab?.id ?? void 0).then(sendResponse);
      return true;
    }
    if (msg.type === "report") {
      void submitReport(msg.scanId, "full", false).then(sendResponse);
      return true;
    }
    if (msg.type === "undo-report") {
      void undoReport(msg.scanId).then(sendResponse);
      return true;
    }
    if (msg.type === "reset-token") {
      void chrome.storage.local.get(null).then(async (all) => {
        await chrome.storage.local.remove(Object.keys(all).filter((k) => k.startsWith("token:")));
        sendResponse({ ok: true, scanId: "" });
      });
      return true;
    }
    return false;
  });
  chrome.runtime.onInstalled.addListener(async () => {
    const { lang } = await getSettings();
    const t = STRINGS[lang];
    await chrome.contextMenus.removeAll();
    chrome.contextMenus.create({ id: "mburoja-email", title: t.menuEmail, contexts: ["selection"] });
    chrome.contextMenus.create({ id: "mburoja-sms", title: t.menuSms, contexts: ["selection"] });
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes.lang) return;
    const t = STRINGS[changes.lang.newValue ?? "sq"];
    for (const [id, title] of [["mburoja-email", t.menuEmail], ["mburoja-sms", t.menuSms]]) {
      try {
        chrome.contextMenus.update(id, { title }, () => void chrome.runtime.lastError);
      } catch {
      }
    }
  });
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    const text = (info.selectionText ?? "").trim();
    if (!text) return;
    void runScan({ kind: "selection", text, as: info.menuItemId === "mburoja-sms" ? "sms" : "email" }, tab?.id).then(async (r) => {
      if (!r.ok) {
        const { lang } = await getSettings();
        await chrome.notifications.create({ type: "basic", iconUrl: chrome.runtime.getURL("icons/icon-128.png"), title: "Mburoja", message: STRINGS[lang].errors[r.error] ?? r.error });
      }
    });
  });
  chrome.runtime.onStartup.addListener(async () => {
    const last = (await getHistory())[0];
    if (last) await setBadge(void 0, last);
  });
})();
