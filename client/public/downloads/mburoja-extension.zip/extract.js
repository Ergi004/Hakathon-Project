"use strict";
(() => {
  // extension/src/content/adapters.ts
  var MAX_HTML = 4e5;
  var MAX_TEXT = 9e4;
  var MAX_LINKS = 150;
  var visible = (el) => !!el && el.getClientRects().length > 0;
  var text = (el) => (el?.textContent ?? "").replace(/\s+/g, " ").trim();
  function unwrapLink(href) {
    try {
      const u = new URL(href);
      if (/(^|\.)google\.[a-z.]+$/.test(u.hostname) && u.pathname === "/url") return u.searchParams.get("q") ?? u.searchParams.get("url") ?? href;
      if (u.hostname.endsWith("safelinks.protection.outlook.com")) return u.searchParams.get("url") ?? href;
      return href;
    } catch {
      return href;
    }
  }
  function linksIn(root) {
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    for (const a of Array.from(root.querySelectorAll("a[href]"))) {
      const raw = a.getAttribute("href") ?? "";
      if (!/^https?:/i.test(raw)) continue;
      const href = unwrapLink(a.href);
      const key = `${href}|${text(a)}`;
      if (seen.has(key)) continue;
      seen.add(key);
      out.push({ href, text: text(a).slice(0, 200) });
      if (out.length >= MAX_LINKS) break;
    }
    return out;
  }
  function cleanHtml(root) {
    const clone = root.cloneNode(true);
    for (const a of Array.from(clone.querySelectorAll("a[href]"))) a.setAttribute("href", unwrapLink(a.href));
    for (const s of Array.from(clone.querySelectorAll("script, style"))) s.remove();
    return clone.innerHTML.slice(0, MAX_HTML);
  }
  function guessMime(name) {
    const ext = name.toLowerCase().split(".").pop() ?? "";
    const map = {
      pdf: "application/pdf",
      zip: "application/zip",
      rar: "application/vnd.rar",
      "7z": "application/x-7z-compressed",
      doc: "application/msword",
      docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      docm: "application/vnd.ms-word.document.macroenabled.12",
      xls: "application/vnd.ms-excel",
      xlsm: "application/vnd.ms-excel.sheet.macroenabled.12",
      xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      html: "text/html",
      htm: "text/html",
      svg: "image/svg+xml",
      exe: "application/x-msdownload",
      js: "text/javascript",
      iso: "application/x-iso9660-image",
      png: "image/png",
      jpg: "image/jpeg",
      jpeg: "image/jpeg"
    };
    return map[ext] ?? "application/octet-stream";
  }
  var FILE_NAME = /[^\\/:*?"<>|\s][^\\/:*?"<>|]*\.[a-z0-9]{2,5}$/i;
  function gmail() {
    if (location.hostname !== "mail.google.com") return null;
    const warnings = [];
    const bodies = Array.from(document.querySelectorAll("div.a3s")).filter(visible);
    const body = bodies.at(-1);
    if (!body) return null;
    const msg = body.closest("div.adn") ?? body.closest("[role='listitem']") ?? document.body;
    const fromEl = msg.querySelector("span.gD[email]") ?? document.querySelector("span.gD[email]");
    const sender = fromEl ? `${fromEl.getAttribute("name") ?? text(fromEl)} <${fromEl.getAttribute("email")}>` : void 0;
    if (!sender) warnings.push("sender_not_found");
    const attachments = [];
    for (const el of Array.from(msg.querySelectorAll("[download_url]"))) {
      const [mime, name] = (el.getAttribute("download_url") ?? "").split(":");
      if (name) attachments.push({ name, mime: mime || guessMime(name), size: 0 });
    }
    if (!attachments.length) {
      for (const el of Array.from(msg.querySelectorAll("span.aV3, div.aQA span"))) {
        const name = text(el);
        if (FILE_NAME.test(name)) attachments.push({ name, mime: guessMime(name), size: 0 });
      }
    }
    warnings.push("headers_not_in_dom");
    return {
      provider: "gmail",
      subject: text(document.querySelector("h2.hP")) || void 0,
      sender,
      body: (body.innerText ?? "").slice(0, MAX_TEXT),
      html: cleanHtml(body),
      links: linksIn(body),
      attachments: dedupe(attachments),
      warnings
    };
  }
  function outlook() {
    if (!OUTLOOK_HOST.test(location.hostname)) return null;
    const warnings = [];
    const body = Array.from(document.querySelectorAll("div[aria-label='Message body'], div[aria-label='Trupi i mesazhit'], div[role='document']")).filter(visible).at(-1) ?? null;
    if (!body) return null;
    const pane = body.closest("[role='main']") ?? body.closest("#ReadingPaneContainerId") ?? document.body;
    const subject = text(pane.querySelector("[role='heading'][aria-level='2']")) || text(document.querySelector("#ReadingPaneContainerId [role='heading']")) || void 0;
    let sender;
    const titled = Array.from(pane.querySelectorAll("[title*='@']")).find((e) => /@/.test(e.getAttribute("title") ?? ""));
    if (titled) {
      const addr = (titled.getAttribute("title") ?? "").match(/[^\s<>]+@[^\s<>]+/)?.[0];
      sender = addr ? `${text(titled).replace(/<.*>/, "").trim() || addr} <${addr}>` : void 0;
    }
    if (!sender) {
      const m = pane.innerText?.slice(0, 2e3).match(/([^\n<]{0,60})<([^\s<>]+@[^\s<>]+)>/);
      if (m) sender = `${m[1].trim()} <${m[2]}>`;
    }
    if (!sender) warnings.push("sender_not_found");
    const attachments = [];
    for (const el of Array.from(pane.querySelectorAll("[role='listbox'] [role='option'], [data-testid*='ttachment'] [title]"))) {
      const name = (el.getAttribute("title") ?? text(el)).split("\n")[0].trim();
      if (FILE_NAME.test(name)) attachments.push({ name, mime: guessMime(name), size: 0 });
    }
    warnings.push("headers_not_in_dom");
    return {
      provider: "outlook",
      subject,
      sender,
      body: (body.innerText ?? "").slice(0, MAX_TEXT),
      html: cleanHtml(body),
      links: linksIn(body),
      attachments: dedupe(attachments),
      warnings
    };
  }
  function generic(selectionOnly = false) {
    const sel = window.getSelection();
    let root = null;
    let body = "";
    const selected = !!sel && sel.toString().trim().length > 20 && sel.rangeCount > 0;
    if (selected) {
      body = sel.toString();
      const c = sel.getRangeAt(0).commonAncestorContainer;
      root = c.nodeType === 1 ? c : c.parentElement;
    } else if (!selectionOnly) {
      root = document.querySelector("[role='main'], main, article") ?? document.body;
      body = root.innerText ?? "";
    }
    if (!body.trim() || !root) return null;
    const sender = selected ? body.slice(0, 1500).match(/[^\s<>()"']+@[^\s<>()"']+\.[a-z]{2,}/i)?.[0] : void 0;
    return {
      provider: "webmail",
      sender,
      body: body.slice(0, MAX_TEXT),
      links: linksIn(root),
      attachments: [],
      warnings: ["generic_adapter", "headers_not_in_dom", ...selected ? ["selection"] : []]
    };
  }
  function dedupe(list) {
    const seen = /* @__PURE__ */ new Set();
    return list.filter((a) => seen.has(a.name) ? false : (seen.add(a.name), true)).slice(0, 50);
  }
  var OUTLOOK_HOST = /^outlook\.(live|office|office365)\.com$/;
  function extractOpenEmail() {
    if (location.hostname === "mail.google.com") return gmail() ?? generic(true) ?? { error: "open_message" };
    if (OUTLOOK_HOST.test(location.hostname)) return outlook() ?? generic(true) ?? { error: "open_message" };
    return generic() ?? { error: "no_message" };
  }

  // extension/src/content/extract.ts
  globalThis.__mburojaExtract = extractOpenEmail;
})();
